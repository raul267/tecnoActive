<div class="col-md-12 text-center"><h1>Registrar producto</h1></div>
  <div class="col-md-12" style="background-color:black;"></div>
<div class="container">
  <form action="?c=Usuario&a=InsertarProducto" border="1" style="" method="post">
    <div class="row" style="margin-top:80px;">
      <div class="row">
        <div class="col-md-3">
          <label>id producto</label>
          <input type="text" class=""name="idProducto" id="idProducto" value="">
        </div>
        <div class="col-md-3">
          <label>Descripcion</label>
          <input type="text" class=""name="descripcion" id="descripcion" value="">
        </div>
      </div>
        <div class="row">
          <div class="col-md-2">
            <label>Valor:</label>
            <input type="text" name="valor" id="valor" value="">
          </div>
        </div>
      </div>
      <br>
    <div class="col-md-4">
      <button style="float:left;" class="btn btn-success" onclick=""  id="btnRegistrar">Registar Producto</button>
    </div>
  </form>




</div>
</div>
